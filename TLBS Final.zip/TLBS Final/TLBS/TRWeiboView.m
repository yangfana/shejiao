//
//  TRWeiboView.m
//  TLBS
//
//  Created by tarena on 14-7-23.
//  Copyright (c) 2014年 tarena. All rights reserved.
//

#import "TRWeiboView.h"

@implementation TRWeiboView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        [self initUI];
    }
    return self;
}
//添加需要用到的各种控件
-(void)initUI{
    float width = 260;
    if (self.isDetail) {
        width = 300;
    }
    self.textView = [[UITextView alloc]initWithFrame:CGRectMake(0, 0, width, 0)];
    self.textView.userInteractionEnabled = NO;
     self.textView.font = [UIFont systemFontOfSize:14];
    [self addSubview:self.textView];
    self.textView.backgroundColor = [UIColor clearColor];
    self.imageView = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, width, 90)];
    [self.imageView setContentMode:UIViewContentModeScaleAspectFit];
  
    [self addSubview:self.imageView];
}
//每次控件显示之前会调用 切记不能在此方法内直接创建新控件  应该写的内容是 更新显示效果的代码（尺寸或内容）
-(void)layoutSubviews{
    [super layoutSubviews];
    float width = 260;
    if (self.isDetail) {
        width = 300;
    }
    //计算文本高度
    CGRect frame = [self.weibo.text boundingRectWithSize:CGSizeMake(width, 999) options:NSStringDrawingUsesLineFragmentOrigin  attributes:@{NSFontAttributeName : [UIFont systemFontOfSize:14]} context:nil];
    self.textView.frame = CGRectMake(0, 0, width, frame.size.height+10);
    self.textView.text = self.weibo.text;
    
    //如果存在图片
    if (self.weibo.thumbnailImage && ![self.weibo.thumbnailImage isEqualToString:@""]) {
        self.imageView.hidden = NO;
        self.imageView.frame = CGRectMake(-20,self.textView.frame.size.height+10, width, 90);
     dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
         NSData *data = [NSData dataWithContentsOfURL:[NSURL URLWithString:self.weibo.thumbnailImage]];
         UIImage *image = [UIImage imageWithData:data];
         dispatch_async(dispatch_get_main_queue(), ^{
             self.imageView.image = image;
         });
     });
    }else{//如果没有图片把图片隐藏
        self.imageView.hidden = YES;
    }
//**************添加转发**************************
    if (self.weibo.relWeibo) {
        //第一次需要创建 之后直接复用
        if (!self.relWeiboView) {
            self.relWeiboView = [[TRWeiboView alloc]initWithFrame:CGRectZero];
            self.relWeiboView.isDetail = self.isDetail;
            [self.relWeiboView setBackgroundColor:[UIColor colorWithRed:223/255.0 green:223/255.0 blue:223/255.0 alpha:1]];
            [self addSubview:self.relWeiboView];
        }
        //        复用的时候如果没有转发需要隐藏  有则显示出来
        self.relWeiboView.hidden = NO;
        self.relWeiboView.frame = CGRectMake(0, self.textView.frame.size.height+10, width, [self.relWeiboView.weibo getWeiboHeightIsDetailPage:self.isDetail]);
        self.relWeiboView.weibo = self.weibo.relWeibo;
    }else{
        self.relWeiboView.hidden = YES;
    }
//********************************************
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end
