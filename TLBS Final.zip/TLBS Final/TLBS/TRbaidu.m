//
//  TRbaidu.m
//  TLBS
//
//  Created by tarena on 14-12-5.
//  Copyright (c) 2014年 tarena. All rights reserved.
//

#import "TRbaidu.h"

@interface TRbaidu ()
//- (IBAction)clicked:(UIButton *)sender;

@end

@implementation TRbaidu

- (void)viewDidLoad
{
    [super viewDidLoad];
    webView = [[UIWebView alloc] initWithFrame:CGRectMake(0, 70, 320, 568)];
    NSURLRequest *request =[NSURLRequest requestWithURL:[NSURL URLWithString:@"http://www.baidu.com"]];
    [self.view addSubview: webView];
    [webView loadRequest:request];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

//- (IBAction)clicked:(UIButton *)sender {
//    NSString *urlString = Nil;
//    urlString = @"http://www.baidu.com";
//    NSURL *url = [NSURL URLWithString:urlString];
//    [[UIApplication sharedApplication]openURL:url];
//    UILabel *lable = [[UILabel alloc]initWithFrame:CGRectMake(0, 10, 20, 20)];
//    lable.backgroundColor = [UIColor redColor];
//}
@end
