//
//  TRXMPPManager.h
//  Day22XMPP
//
//  Created by tarena on 14-7-28.
//  Copyright (c) 2014年 Tarena. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "XMPPFramework.h"
@protocol XMPPManagerDelegate <NSObject>
@required
-(void)didReceiveMessage:(XMPPMessage*)message;

@end

@interface TRXMPPManager : NSObject
@property (nonatomic ,strong)XMPPStream *xmppStream;
@property (nonatomic, weak)id<XMPPManagerDelegate> delegate;
@property (nonatomic, copy)NSString *password;
+(TRXMPPManager *)shareManager;
-(void)initXMPPWithUserName:(NSString *)userName andPassword:(NSString *)password;
-(XMPPMessage *)sendMessageBody:(NSString *)body andType:(NSString*)type andToUserName:(NSString *)toUserName;

@end

