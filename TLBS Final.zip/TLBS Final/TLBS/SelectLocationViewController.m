//
//  SelectLocationViewController.m
//  TLBS-Project
//
//  Created by ivan liu on 14-1-2.
//  Copyright (c) 2014年 Wei WenRu. All rights reserved.
//
#import <MapKit/MapKit.h>
#import "SelectLocationViewController.h"

@interface SelectLocationViewController ()
@property (weak, nonatomic) IBOutlet MKMapView *myMV;
@property (nonatomic, strong)CLLocationManager *manager;
@end

@implementation SelectLocationViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.title = @"选择位置";
 
  

    CLLocationCoordinate2D coord;
    coord.latitude =39.90960456049752;
    coord.longitude =116.3972282409668;
    MKCoordinateRegion region = MKCoordinateRegionMake(coord, MKCoordinateSpanMake(0.1, 0.1));
    [self.myMV setRegion:region animated:YES];
    
    //设置一个默认地址
    self.deletage.seletedCoord = coord;
    
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



- (IBAction)cancelAction:(id)sender {
    [self.navigationController popViewControllerAnimated:YES];
}
- (IBAction)tapMapAction:(UITapGestureRecognizer *)sender {
    
   
    CGPoint p = [sender locationInView:self.view];
 
    self.deletage.seletedCoord =  [self.myMV convertPoint:p toCoordinateFromView:self.view];
   
    self.laLabel.text = [NSString stringWithFormat:@"%f",self.deletage.seletedCoord.latitude];
    self.loLabel.text = [NSString stringWithFormat:@"%f",self.deletage.seletedCoord.longitude];

}

@end
