//
//  TRTextView.h
//  Day9TextView
//
//  Created by tarena on 14-5-28.
//  Copyright (c) 2014年 tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TRTextView : UIView
@property (nonatomic, strong)UITextView *textView;
@property (nonatomic, strong)UIImageView *imageView;

@property (nonatomic, copy)NSString *text;


@property (nonatomic)BOOL isRight;


@end
