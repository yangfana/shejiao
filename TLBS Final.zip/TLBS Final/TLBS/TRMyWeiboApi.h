//
//  TRMyWeiboApi.h
//  TLBS
//
//  Created by tarena on 14-9-17.
//  Copyright (c) 2014年 tarena. All rights reserved.
//
#define BASE_URL @"http://open.t.qq.com/api/"
typedef void (^MyCallback)(id obj);
#import <UIKit/UIKit.h>
#import "WeiboApi.h"
#import "TRUserInfo.h"
@interface TRMyWeiboApi : WeiboApi
@property (nonatomic, copy)NSString *normalParams;

+(TRMyWeiboApi *)shareWeiboApi;

-(void)requestUserInfo:(MyCallback)callback;

//查询名单列表
-(void)requestLists:(MyCallback)callback;
//创建名单
-(void)createListByName:(NSString *)name withCallBack:(MyCallback)callback;
//删除名单
-(void)deleteListByID:(NSString *)listID;

//查询名单下好友列表
-(void)requestFriendsByListID:(NSString *)listID withCallBack:(MyCallback)callback;
//添加好友到名单
-(void)addFriendsByName:(NSString *)name listID:(NSString *)listid andCallBack:(MyCallback)callback;
//从名单中删除好友
-(void)deleteFriendsByName:(NSString *)name listID:(NSString *)listid andCallBack:(MyCallback)callback;
//获取某个用户信息
-(void)getDetailUserInfoByUserInfo:(TRUserInfo*)userInfo andCallback:(MyCallback)callback;

//查询某用户发布的最新微博
-(void)requestTimelineWithOpenID:(NSString *)openID andCallBack:(MyCallback)callback;
//查询微博评论或转发列表 type=0转发列表  type=1评论列表
-(void)requestWeiboCommentWithWeiboID:(NSString *)weiboID andCallBack:(MyCallback)callback andType:(NSString *)type;

//添加一条评论
-(void)addCommentWithWeiboID:(NSString *)weiboID andContent:(NSString*)content andCallBack:(MyCallback)callback;
//转发
-(void)relayWithWeiboID:(NSString *)weiboID andContent:(NSString*)content andCallBack:(MyCallback)callback;
//批量获取微博详情
-(void)requestWeibosByweiboIDs:(NSArray *)weiboIDs complation:(MyCallback)complation;
@end
