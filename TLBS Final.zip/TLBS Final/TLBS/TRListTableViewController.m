//
//  TRListTableViewController.m
//  TLBS
//
//  Created by tarena on 14-8-19.
//  Copyright (c) 2014年 tarena. All rights reserved.
//

#import "TRListTableViewController.h"
#import "TRMyWeiboApi.h"
#import "TRList.h"
#import "TRFriendViewController.h"
@interface TRListTableViewController ()
@property (nonatomic, strong)NSMutableArray *lists;
@end

@implementation TRListTableViewController



- (void)viewDidLoad
{
    [super viewDidLoad];
}
//把请求放到willAppear里面 能够使数据实时更新
-(void)viewWillAppear:(BOOL)animated{
    [self requestLists];
}
-(void)requestLists{
    //查询名单列表
    [[TRMyWeiboApi shareWeiboApi]requestLists:^(id obj) {
        self.lists = obj;
        //回主线程刷新界面 因为这里是子线程
        dispatch_async(dispatch_get_main_queue(), ^{
            [self.tableView reloadData];
        });
    }];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source



- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{

    return self.lists.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"Cell" forIndexPath:indexPath];
    
    TRList *list = self.lists[indexPath.row];
    cell.textLabel.text = list.name;
    cell.detailTextLabel.text = [NSString stringWithFormat:@"%d人",list.count];
    
    return cell;
}



// 删除名单
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        TRList *list = self.lists[indexPath.row];
        [self.lists removeObject:list];
        [[TRMyWeiboApi shareWeiboApi]deleteListByID:list.listID];
        
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    }
}



//添加名单
- (IBAction)addList:(id)sender {
    UIAlertView* alert = [[UIAlertView alloc]initWithTitle:@"创建名单" message:@"请输入名单的名称" delegate:self cancelButtonTitle:@"取消" otherButtonTitles:@"确定", nil];
    [alert setAlertViewStyle:UIAlertViewStylePlainTextInput];
    [alert show];
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (buttonIndex == 1) {//添加好友
        NSString* listName = [alertView textFieldAtIndex:0].text;
        
        [[TRMyWeiboApi shareWeiboApi]createListByName:listName withCallBack:^(id obj) {
            //创建名单之后重新查询 刷新显示
            [self requestLists];
        }];
        
    }
}
//点击名单时跳转到名单详情页面 查看名单下所有的好友
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    TRList *list = self.lists[indexPath.row];
    
    [self performSegueWithIdentifier:@"detailevc" sender:list];
}

#pragma mark - Navigation

//跳转页面传参 把点击的名单对象传递过去
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    TRFriendViewController *vc = segue.destinationViewController;
    vc.currentList = sender;
}
@end
