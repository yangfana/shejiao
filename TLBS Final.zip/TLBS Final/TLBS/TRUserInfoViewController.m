//
//  TRUserInfoViewController.m
//  TLBS
//
//  Created by tarena on 14-9-18.
//  Copyright (c) 2014年 tarena. All rights reserved.
//

#import "TRUserInfoViewController.h"
#import "Weibo.h"
#import "TRWeiboCell.h"
#import "TRMyWeiboApi.h"
#import "DetailViewController.h"
@interface TRUserInfoViewController ()
@property (weak, nonatomic) IBOutlet UITableView *tableView;
- (IBAction)changeAction:(UISegmentedControl *)sender;
@property (weak, nonatomic) IBOutlet UIImageView *redIV;
@property (weak, nonatomic) IBOutlet UILabel *introLabel;
@property (weak, nonatomic) IBOutlet UIImageView *headIV;
@property (weak, nonatomic) IBOutlet UISegmentedControl *mySC;

@property (nonatomic, strong)NSMutableArray *weibos;

@end

@implementation TRUserInfoViewController



- (void)viewDidLoad
{
    [super viewDidLoad];
    //如果存在则是查看好友信息
    if (self.userInfo) {
        
        self.title = self.userInfo.nick;
        [[TRMyWeiboApi shareWeiboApi]getDetailUserInfoByUserInfo:self.userInfo andCallback:^(id obj) {
            
            dispatch_async(dispatch_get_main_queue(), ^{
                //回到主线程 更新界面
                [self createUIByUserInfo:obj];
                
            });
        }];
        
        
        //获取好友微博列表
        [[TRMyWeiboApi shareWeiboApi]requestTimelineWithOpenID:self.userInfo.openid andCallBack:^(id obj) {
            self.weibos = obj;
            
            dispatch_async(dispatch_get_main_queue(), ^{
                
                [self.tableView reloadData];
            });
        }];
    }else{//获取自己信息
        
        //隐藏naviBar
        self.navigationController.navigationBarHidden = YES;
        [[TRMyWeiboApi shareWeiboApi] requestUserInfo:^(id obj) {
            
            dispatch_async(dispatch_get_main_queue(), ^{
                
                [self createUIByUserInfo:obj];
            });
        }];
        //获取个人微博列表
        NSString *openID = [[TRMyWeiboApi shareWeiboApi] getToken].openid;
        [[TRMyWeiboApi shareWeiboApi]requestTimelineWithOpenID:openID andCallBack:^(id obj) {
            self.weibos = obj;
            
            dispatch_async(dispatch_get_main_queue(), ^{
                
                [self.tableView reloadData];
            });
        }];
        
        
    }

}
-(void)viewWillAppear:(BOOL)animated{
    if (!self.userInfo) {
          self.navigationController.navigationBarHidden = YES;
    }
}


-(void)createUIByUserInfo:(TRUserInfo*)userInfo{
    
    TRUserInfoView *userInfoView = [[[NSBundle mainBundle]loadNibNamed:@"TRUserInfoView" owner:self options:Nil]lastObject];
    
    userInfoView.userInfo = userInfo;
    userInfoView.frame = CGRectMake(0, 275, 320, 400);
    [self.view addSubview:userInfoView];
    
    [self.mySC setBackgroundImage:[UIImage imageNamed:@"10我的资料_04.png"] forState:UIControlStateNormal barMetrics:UIBarMetricsDefault];
    [self.mySC setBackgroundImage:[UIImage imageNamed:@"10我的资料_04.png"] forState:UIControlStateSelected barMetrics:UIBarMetricsDefault];
    //设置SC的样式
    NSDictionary *att  = @{NSForegroundColorAttributeName: [UIColor grayColor],NSFontAttributeName:[UIFont systemFontOfSize:16]};
    [self.mySC setTitleTextAttributes:att forState:UIControlStateNormal];
    NSDictionary *selectedAtt  = @{NSForegroundColorAttributeName: [UIColor blackColor],NSFontAttributeName:[UIFont systemFontOfSize:16]};
       [self.mySC setTitleTextAttributes:selectedAtt forState:UIControlStateSelected];
    
     self.mySC.frame = CGRectMake(0, self.mySC.frame.origin.y, 320, 50);
    [self.mySC setTintColor:[UIColor lightGrayColor]];

    self.nickLabel.text = userInfo.nick;
    self.introLabel.text = userInfo.introduction;
    //设置图片
    self.headIV.layer.cornerRadius = self.headIV.bounds.size.width/2;
    self.headIV.layer.masksToBounds = YES;
    self.headIV.layer.borderColor = [UIColor whiteColor].CGColor;
    self.headIV.layer.borderWidth = 1.5;
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        NSData *data = [NSData dataWithContentsOfURL:[NSURL URLWithString:userInfo.head]];
        UIImage *image = [UIImage imageWithData:data];
        dispatch_async(dispatch_get_main_queue(), ^{
            self.headIV.image = image;
            
        });
    });
    
    
 
    
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(void)moveImage:(NSTimer*)timer{
    UISegmentedControl *sender = timer.userInfo;
    [UIView animateWithDuration:.2 animations:^{
        self.redIV.center = CGPointMake(sender.selectedSegmentIndex*160 +80, self.redIV.center.y);
    }];
}
- (IBAction)changeAction:(UISegmentedControl *)sender {
    //这里要开timer才能移动红色线
    [NSTimer scheduledTimerWithTimeInterval:.01 target:self selector:@selector(moveImage:) userInfo:sender repeats:NO];
    if (sender.selectedSegmentIndex==0) {
        [self.view bringSubviewToFront:self.tableView];
        self.tableView.hidden = NO;
    }else self.tableView.hidden = YES;
    
}
#pragma mark tableViewDelegate
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.weibos.count;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    Weibo *w = self.weibos[indexPath.row];
    
    return   [w getWeiboHeightIsDetailPage:NO] + 120;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString * cells = @"cell";
    
    TRWeiboCell * cell = [tableView dequeueReusableCellWithIdentifier:cells];
    if(!cell)
    {
        //不用注册 通过xib去加载自定义的Cell
        cell = [[[NSBundle mainBundle] loadNibNamed:@"TRWeiboCell" owner:self options:Nil] lastObject];
    }
    Weibo * weibo = self.weibos[indexPath.row];
    cell.weibo = weibo;
    [cell setNeedsLayout];
    return cell;
}
-(void)viewWillDisappear:(BOOL)animated{
    self.navigationController.navigationBarHidden = NO;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
     Weibo * weibo = self.weibos[indexPath.row];
    
    [self performSegueWithIdentifier:@"detailvc" sender:weibo];
}
-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender{
    DetailViewController *vc = segue.destinationViewController;
    vc.weibo = sender;
    
    
}
@end
