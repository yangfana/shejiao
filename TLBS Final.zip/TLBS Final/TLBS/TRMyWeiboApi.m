//
//  TRMyWeiboApi.m
//  TLBS
//
//  Created by tarena on 14-9-17.
//  Copyright (c) 2014年 tarena. All rights reserved.
//

#import "TRMyWeiboApi.h"
#import "WeiboPaser.h"
#import "constant.h"
static TRMyWeiboApi *weiboApi;
@implementation TRMyWeiboApi
+(TRMyWeiboApi *)shareWeiboApi{
    if (!weiboApi) {
        weiboApi = [[TRMyWeiboApi alloc]initWithAppKey:WiressSDKDemoAppKey andSecret:WiressSDKDemoAppSecret andRedirectUri:REDIRECTURI andAuthModeFlag:0 andCachePolicy:0] ;
    }
    
    return weiboApi;
}
-(NSString *)normalParams{
    if (!_normalParams) {
        WeiboApi *weiboApi = [TRMyWeiboApi shareWeiboApi];
        WeiboApiObject *obj = [weiboApi getToken];
        
        _normalParams = [NSString stringWithFormat:@"oauth_consumer_key=%@&access_token=%@&openid=%@&oauth_version=2.a",WiressSDKDemoAppKey,obj.accessToken,obj.openid];
    }
    return _normalParams;
}
-(void)requestUserInfo:(MyCallback)callback{
    
    [self getByApiName:@"user/info" andParams:@"format=json" andCallback:^(id obj) {
        
        TRUserInfo *userInfo = [WeiboPaser paseUserInfoByDictionary:obj];
        callback(userInfo);
    }];
}
//查询名单列表
-(void)requestLists:(MyCallback)callback{
    
    [self postByApiName:@"list/get_list" andParams:@"format=json" andCallback:^(id obj) {
        NSArray *lists = [WeiboPaser paseListsByJsonDic:obj];
        callback(lists);
    }];
     }

//创建名单
-(void)createListByName:(NSString *)name withCallBack:(MyCallback)callback{
    [self postByApiName:@"list/create" andParams:[NSString stringWithFormat:@"format=json&tag=TLBS&access=1&name=%@&description=微身边专用",name] andCallback:^(id obj) {
        NSLog(@"%@",obj);
        //创建成功后得到listID
        NSString *listID = [WeiboPaser paseListIDByDic:obj];
        
        callback(listID);
    }];
}
//查询
-(void)requestFriendsByListID:(NSString *)listID    withCallBack:(MyCallback)callback{
    
    NSString *params = [NSString stringWithFormat:@"format=json&pageflag=0&listid=%@",listID];
    [self getByApiName:@"list/listusers" andParams:params andCallback:^(id obj) {
        
        NSArray *users = [WeiboPaser paseAllUserByJsonDic:obj];
        callback(users);
    }];
    
}
//添加好友到指定列表
-(void)addFriendsByName:(NSString *)name listID:(NSString *)listid andCallBack:(MyCallback)callback{
    
    NSString *params = [NSString stringWithFormat:@"format=json&names=%@&listid=%@",name,listid];
    
    [self postByApiName:@"list/add_to_list" andParams:params andCallback:^(id obj) {
        callback(obj);
    }];
    
}
//删除名单
-(void)deleteListByID:(NSString *)listID{
    
    NSString *params = [NSString stringWithFormat:@"format=json&listid=%@",listID];
    
    [self postByApiName:@"list/delete" andParams:params andCallback:^(id obj) {
        NSLog(@"删除名单：%@",obj);
    }];
    
    
}
//从名单中删除好友
-(void)deleteFriendsByName:(NSString *)name listID:(NSString *)listid andCallBack:(MyCallback)callback{
    
    NSString *params = [NSString stringWithFormat:@"format=json&names=%@&listid=%@",name,listid];
    
    [self postByApiName:@"list/del_from_list" andParams:params andCallback:^(id obj) {
        callback(obj);
    }];
    
}

#pragma mark GetAndPost
-(void)postByApiName:(NSString *)apiName andParams:(NSString *)params andCallback:(MyCallback)callback{
    NSString *path = [NSString stringWithFormat:@"%@%@",BASE_URL,apiName];
    NSString *allParams = [NSString stringWithFormat:@"%@&%@",self.normalParams,params];
 
    NSURL *url = [NSURL URLWithString:path];
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url];
    [request setHTTPMethod:@"Post"];
    [request setHTTPBody:[allParams dataUsingEncoding:NSUTF8StringEncoding]];
    
    NSURLSession *session = [NSURLSession sharedSession];
    NSURLSessionDataTask *task = [session dataTaskWithRequest:request completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
        NSString *str = [[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding];
        NSLog(@"%@",str);
        NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:data options:0 error:Nil];
        callback(dic);
    }];
    [task resume];
}
-(void)getByApiName:(NSString *)apiName andParams:(NSString *)params andCallback:(MyCallback)callback{
    NSString *path = [NSString stringWithFormat:@"%@%@?%@&%@",BASE_URL,apiName,self.normalParams,params];
    NSURL *url = [NSURL URLWithString:path];
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url];
    
    NSURLSession *session = [NSURLSession sharedSession];
    NSURLSessionDataTask *task = [session dataTaskWithRequest:request completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
        NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:data options:0 error:Nil];
        
        callback(dic);
    }];
    [task resume];

}


//获取某个好友用户信息
-(void)getDetailUserInfoByUserInfo:(TRUserInfo *)userInfo andCallback:(MyCallback)callback{
    NSString *params = [NSString stringWithFormat:@"format=json&fopenid=%@",userInfo.openid];
    
    [self getByApiName:@"user/other_info" andParams:params andCallback:^(id obj) {
        NSDictionary *dic = obj;
        
        NSDictionary *dataDic = [dic objectForKey:@"data"];
        TRUserInfo *userInfo = [WeiboPaser paseUserInfoByDictionary:dataDic];
        callback(userInfo);
    }];
}


//请求某用户所发的最新微博
-(void)requestTimelineWithOpenID:(NSString *)openID andCallBack:(MyCallback)callback{
    NSString *params = [NSString stringWithFormat:@"&format=json&fopenid=%@&listid=0&reqnum=20&pageflag=0&type=3&contenttype=0&pageTime=0",openID];
    [self postByApiName:@"statuses/user_timeline" andParams:params andCallback:^(id obj) {
        //得到json字典之后解析该字典 得到多个Weibo对象 通过callback返回回去
        NSDictionary *dic = [obj objectForKey:@"data"];
        NSArray *weibosDic = [dic objectForKey:@"info"];
        NSMutableArray *weibos = [NSMutableArray array];
        for (NSDictionary *weiboDic in weibosDic) {
            Weibo *w = [WeiboPaser paseWeiboByDictionary:weiboDic];
            [weibos addObject:w];
        }
        callback(weibos);
    }];
}

-(void)requestWeiboCommentWithWeiboID:(NSString *)weiboID andCallBack:(MyCallback)callback andType:(NSString *)type{
    NSString *params = [NSString stringWithFormat:@"format=json&flag=%@&rootid=%@&reqnum=100&pagetime=0&pageflag=0",type,weiboID];
    
    [self getByApiName:@"t/re_list" andParams:params andCallback:^(id obj) {
        NSDictionary *dataDic = [obj objectForKey:@"data"];
          NSMutableArray *comments =[NSMutableArray array];
        if ([dataDic isMemberOfClass:[NSNull class]]) {
            callback(comments);
            return ;
        }
        NSArray *commentsDic = [dataDic objectForKey:@"info"];
      
        for (NSDictionary *commentDic in commentsDic) {
            Comment *c = [WeiboPaser paseCommentsByDictionary:commentDic];
            [comments addObject:c];
            
        }
        callback(comments);
    }];
    
    
}
-(void)addCommentWithWeiboID:(NSString *)weiboID andContent:(NSString *)content andCallBack:(MyCallback)callback{
    NSString *params = [NSString stringWithFormat:@"format=json&content=%@&reid=%@",content,weiboID];
    
    [self postByApiName:@"t/comment" andParams:params andCallback:^(id obj) {
        
        callback(obj);
    }];
    
}
-(void)relayWithWeiboID:(NSString *)weiboID andContent:(NSString *)content andCallBack:(MyCallback)callback{
    NSString *params = [NSString stringWithFormat:@"format=json&content=%@&reid=%@",content,weiboID];
    
    [self postByApiName:@"t/re_add" andParams:params andCallback:^(id obj) {
        
        callback(obj);
    }];
    
}
-(void)requestWeibosByweiboIDs:(NSArray *)weiboIDs complation:(MyCallback)complation{
    NSString *weiboIDsString = [weiboIDs componentsJoinedByString:@","];
    NSLog(@"%@",weiboIDsString);
    NSString *params = [NSString stringWithFormat:@"%@&format=json&ids=%@",self.normalParams,weiboIDsString];
  
    [self getByApiName:@"t/list" andParams:params andCallback:^(id obj) {
     
        NSDictionary *dataDic = [obj objectForKey:@"data"];
        if ([dataDic isMemberOfClass:[NSNull class]]) {
            complation(Nil);
        }
        NSMutableArray *weibos = [NSMutableArray array];
        NSArray *weiboDics = [dataDic objectForKey:@"info"];
        for (NSDictionary *weiboDic in weiboDics) {
            Weibo *w = [WeiboPaser paseWeiboByDictionary:weiboDic];
            [weibos addObject:w];
        }
        complation(weibos);

    }];
    
    
    
}

@end
