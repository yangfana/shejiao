//
//  RecordButton.m
//  TLBS
//
//  Created by tarena on 14-4-8.
//  Copyright (c) 2014年 tarena. All rights reserved.
//

#import "RecordButton.h"

@implementation RecordButton

- (id)initWithCoder:(NSCoder *)aDecoder
{
    self = [super initWithCoder:aDecoder];
    if (self) {
        [self initRecord];
    }
    return self;
}
- (void)initRecord{
    //录制caf格式的路径
    NSString *path = [NSHomeDirectory() stringByAppendingPathComponent:@"Documents/%d.MP3"];
    NSURL *recordedFileURL = [[NSURL alloc] initFileURLWithPath:path] ;
    
    //录音设置
    NSMutableDictionary *settings = [[NSMutableDictionary alloc] init];
    //录音格式 无法使用
    [settings setValue :[NSNumber numberWithInt:kAudioFormatLinearPCM] forKey: AVFormatIDKey];
    //采样率
    [settings setValue :[NSNumber numberWithFloat:11025.0] forKey: AVSampleRateKey];//44100.0
    //通道数
    [settings setValue :[NSNumber numberWithInt:2] forKey: AVNumberOfChannelsKey];
    //音频质量,采样质量
    [settings setValue:[NSNumber numberWithInt:AVAudioQualityMin] forKey:AVEncoderAudioQualityKey];
    
    
    //创建录音对象
    self.recorder = [[AVAudioRecorder alloc] initWithURL:recordedFileURL settings:settings error:nil];
    [self.recorder prepareToRecord];
    
    [self addTarget:self action:@selector(beginAction) forControlEvents:UIControlEventTouchDown];
    [self addTarget:self action:@selector(endAction) forControlEvents:UIControlEventTouchUpInside];
}
-(void)beginAction{
      [self.recorder record];
}

-(void)endAction{
    [self.recorder stop];
    
    //发送音频
     NSString *mp3FilePath = [NSHomeDirectory() stringByAppendingPathComponent:@"Documents/temp.caf"];
    NSData *audioData = [NSData dataWithContentsOfFile:mp3FilePath];
    
    NSString *audioString = [audioData base64EncodedStringWithOptions:0];
    
    [self.delegate sendMessageString:audioString andType:@"audio"];
}



@end
