//
//  TRAppDelegate.h
//  TLBS
//
//  Created by tarena on 14-9-17.
//  Copyright (c) 2014年 tarena. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ICSDrawerController.h"
#import "TRMainTabBarViewController.h"
@interface TRAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;
@property (nonatomic, strong)ICSDrawerController *drawer;
@property (nonatomic, strong)TRMainTabBarViewController *mainTabbarController;
@end
