//
//  DetailViewController.m
//  Day10WeiboDemo
//
//  Created by apple on 13-11-27.
//  Copyright (c) 2013年 tarena. All rights reserved.
//
#import "WeiboPaser.h"
#import "TRMyWeiboApi.h"
#import "DetailViewController.h"
#import "TRAppDelegate.h"
#import "TRWeiboHeaderView.h"
#import "Comment.h"
#import "CommentCell.h"

#import "TRWeiboView.h"

 
@interface DetailViewController ()
@property (nonatomic,strong)NSMutableArray *comments;
@property (nonatomic)BOOL isComment;
@property (nonatomic, strong)UILabel *commentCountLabel;
@property (nonatomic, strong)UITextField *sendInfoTF;
@property (nonatomic, strong)NSMutableArray *requests;
@property (nonatomic, strong)UIToolbar *toolbar;
- (IBAction)clicked:(UIButton *)sender;
@property (nonatomic, strong)TRWeiboHeaderView *headerView;
@end

@implementation DetailViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.title = @"微博详情";
       self.isComment = YES;
    //添加原微博内容
    [self initHeaderView];
    [self loadInfo];
    //初始化toolbar
    [self initToolbar];
    
 
}
-(void)initToolbar{
    self.toolbar = [[UIToolbar alloc]initWithFrame:CGRectMake(0, self.view.bounds.size.height-45, 320, 45)];
    
    self.sendInfoTF = [[UITextField alloc]initWithFrame:CGRectMake(10, 5, 260, 35)];
    [self.sendInfoTF setPlaceholder:@"写评论"];
    [self.sendInfoTF setBorderStyle:UITextBorderStyleBezel];
    UIBarButtonItem *bbi = [[UIBarButtonItem alloc]initWithImage:[UIImage imageNamed:@"03话题详情_11.png"] style:UIBarButtonItemStyleBordered target:self action:@selector(sendAction)];
    UIBarButtonItem *sendInfoBBI = [[UIBarButtonItem alloc]initWithCustomView:self.sendInfoTF];
    self.toolbar.items = @[sendInfoBBI,bbi];
    
    [self.navigationController.view addSubview:self.toolbar];
    //监听软键盘事件
     [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(WillChangeFrame:) name:UIKeyboardWillChangeFrameNotification object:nil];
    self.sendInfoTF.delegate = self;
}

//离开页面的时候把toolbar删除
-(void)viewWillDisappear:(BOOL)animated{
    [self.toolbar removeFromSuperview];
}
//控制toolbar位置
#pragma mark - keyboard reference
-(void)WillChangeFrame:(NSNotification *)notif{
    
    NSDictionary *info = [notif userInfo];
    NSValue *value = [info objectForKey:UIKeyboardFrameEndUserInfoKey];
    CGSize keyboardSize = [value CGRectValue].size;
    //收起软键盘的是hi偶
    if (value.CGRectValue.origin.y>400) {
        [UIView animateWithDuration:.2 animations:^{
            self.toolbar.frame = CGRectMake(0, self.view.bounds.size.height-45, 320, 45);
        }];
        
        
    }else{//弹出软键盘的时候
        
        [UIView animateWithDuration:.2 animations:^{
            CGRect frame = self.toolbar.frame;
            frame.origin.y = self.view.bounds.size.height -  keyboardSize.height - self.toolbar.bounds.size.height;
            self.toolbar.frame = frame;
        }];
        
        
    }
    
    
    
}

-(void)loadInfo{
    
//    通过type区分是评论 还是转发
    NSString *type = self.isComment? @"1":@"0";
    [[TRMyWeiboApi shareWeiboApi]requestWeiboCommentWithWeiboID:self.weibo.weiboId andCallBack:^(id obj) {
        
        self.comments = obj;
        dispatch_async(dispatch_get_main_queue(), ^{
            [self.tableView reloadData];
        });
        
    } andType:type];
}

-(void)initHeaderView{
    
    self.headerView = (TRWeiboHeaderView*)self.tableView.tableHeaderView;
    
    self.headerView.weibo = self.weibo;
    self.headerView.frame = CGRectMake(0, 0, 320, [self.weibo getWeiboHeightIsDetailPage:YES]+120);
}

//发送按钮
-(void)sendAction{
    [self.sendInfoTF resignFirstResponder];
    if (self.isComment) {
        [[TRMyWeiboApi shareWeiboApi]addCommentWithWeiboID:self.weibo.weiboId andContent:self.sendInfoTF.text andCallBack:^(id obj) {
           //重新加载数据
            [self loadInfo];
        }];
        
        
    }else{//如果是转发
        [[TRMyWeiboApi shareWeiboApi]relayWithWeiboID:self.weibo.weiboId andContent:self.sendInfoTF.text andCallBack:^(id obj) {
               //重新加载数据
            [self loadInfo];
        }];
    }
    //清空文本输入框
      self.sendInfoTF.text = @"";
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    
}
//点击转发 评论按钮
- (IBAction)clicked:(UIButton *)sender {
    
    
    if (sender.tag==0) {
        [self.headerView.transNums setSelected:YES];
        [self.headerView.commentNum setSelected:NO];
    
        self.isComment = NO;
        [self.sendInfoTF setPlaceholder:@"写转发"];
    }else{
        self.isComment = YES;
        [self.headerView.transNums setSelected:NO];
        [self.headerView.commentNum setSelected:YES];
           [self.sendInfoTF setPlaceholder:@"写评论"];
    }
        [self loadInfo];
}

#pragma mark - Table view data source
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.comments.count;
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    Comment *comment = [self.comments objectAtIndex:indexPath.row];
    return comment.getCommentHight+40;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    CommentCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier forIndexPath:indexPath];
    Comment *comment = [self.comments objectAtIndex:indexPath.row];
    cell.comment = comment;
    return cell;
}

@end
