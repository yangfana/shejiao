//
//  TRHomeViewController.m
//  TLBS
//
//  Created by tarena on 14-9-17.
//  Copyright (c) 2014年 tarena. All rights reserved.
//

#import "TRHomeViewController.h"
#import "TRXMPPManager.h"
#import "TRAppDelegate.h"
#import "TRAnnotation.h"
#import "TRMyWeiboApi.h"
#import "TRMapUtils.h"
#import "TRWeiboCell.h"
#import "DetailViewController.h"
#import "Weibo.h"
#import <MapKit/MapKit.h>
@interface TRHomeViewController ()
@property (nonatomic, strong)NSMutableArray *weibos;
@property (nonatomic, strong)UIView *headerView;
@end

@implementation TRHomeViewController
- (IBAction)clickedMenu:(id)sender {
    
    TRAppDelegate *app = [UIApplication sharedApplication].delegate;
    
    [app.drawer open];
    
}


- (void)viewDidLoad
{
    [super viewDidLoad];
 
    
    [[TRMyWeiboApi shareWeiboApi] loginWithDelegate:self andRootController:self];
    
    
    //添加出地图的按钮
    UIBarButtonItem *mapItem = [[UIBarButtonItem alloc]initWithBarButtonSystemItem:UIBarButtonSystemItemBookmarks target:self action:@selector(clickedMapAction)];
    [mapItem setTintColor:[UIColor grayColor]];
 
    self.navigationItem.rightBarButtonItems = @[self.navigationItem.rightBarButtonItem,mapItem];
}

-(void)clickedMapAction
{
    if (!self.tableView.tableHeaderView)
    {
        self.headerView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, 320, 300)];
        self.headerView .backgroundColor = [UIColor redColor];
        
        MKMapView *mapView = [[MKMapView alloc]initWithFrame: self.headerView .bounds];
        //地图的样式
        /* MKMapTypeStandard = 0,
         MKMapTypeSatellite,
         MKMapTypeHybrid*/
        mapView.mapType = MKMapTypeHybrid;
        CLLocationCoordinate2D coord;
        coord.longitude = 116.3972282409668;
        coord.latitude = 39.90960456049752;
        //显示一个默认的地址
        [mapView setRegion:MKCoordinateRegionMake(coord, MKCoordinateSpanMake(0.01, 0.01))];
        //创建大头针
        
        
        for (Weibo *weibo in self.weibos)
        {
            TRAnnotation *ann = [[TRAnnotation alloc]init];
            CLLocationCoordinate2D coord;
            coord.longitude = weibo.longitude.floatValue;
            coord.latitude = weibo.latitude.floatValue;
            NSLog(@"longitude=%flatitude=%f",coord.longitude,coord.latitude);
            ann.title = weibo.user.nick;
            [ann setCoordinate:coord];
         
            
            [mapView addAnnotation:ann];
            
            
            
        }
        
        
        
        
        
        [ self.headerView  addSubview:mapView];
        
        self.tableView.tableHeaderView =  self.headerView ;
        
        [self.tableView setContentOffset:CGPointMake(0, 0) animated:YES];
    }
    else
    {
        
        self.tableView.tableHeaderView=nil;
        [self.tableView reloadData];
    }
    
    
    
}
-(void)viewDidAppear:(BOOL)animated{
    //获取周边位置信息
    [self loadNearByWeibos];
}

-(void)loadNearByWeibos{
    //因为真机获取不到经纬度 创建一个默认的位置
    CLLocationCoordinate2D l;
    l.latitude =39.904965;
    l.longitude =116.406636;
    NSString *location = [NSString stringWithFormat:@"%f,%f",l.longitude,l.latitude];
    //给百度发请求获取weiboID
    [TRMapUtils serchPoiByLocation:location complation:^(id obj) {
        NSArray *weiboIDs = obj;
        if (weiboIDs.count!=0) {
            
            //向腾讯发请求通过weiboID获得Weibo对象
            [[TRMyWeiboApi shareWeiboApi]requestWeibosByweiboIDs:weiboIDs complation:^(id obj) {
                self.weibos = obj;
                dispatch_async(dispatch_get_main_queue(), ^{
                    [self.tableView reloadData];
                });
            }];
        }
    }];
    
}

-(UIStatusBarStyle)preferredStatusBarStyle{
    
    return UIStatusBarStyleLightContent;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source


#pragma mark tableViewDelegate
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.weibos.count;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
   
    Weibo *w = self.weibos[indexPath.row];
    return   [w getWeiboHeightIsDetailPage:NO] + 120;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString * cells = @"cell";
    
    TRWeiboCell * cell = [tableView dequeueReusableCellWithIdentifier:cells];
    if(!cell)
    {
        //不用注册 通过xib去加载自定义的Cell
        cell = [[[NSBundle mainBundle] loadNibNamed:@"TRWeiboCell" owner:self options:Nil] lastObject];
    }
    Weibo * weibo = self.weibos[indexPath.row];
    cell.weibo = weibo;
    [cell setNeedsLayout];
    return cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    Weibo * weibo = self.weibos[indexPath.row];
    
    [self performSegueWithIdentifier:@"detailvc" sender:weibo];
}
-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender{
    if ([segue.identifier isEqualToString:@"detailvc"]) {
        DetailViewController *vc = segue.destinationViewController;
        vc.weibo = sender;
    }

    
    
}


- (void)DidAuthFinished:(WeiboApiObject *)wbobj{
    
    [[TRMyWeiboApi shareWeiboApi] requestUserInfo:^(id obj) {
        TRUserInfo *mySelfUserInfo = obj;
        TRXMPPManager *manager = [TRXMPPManager shareManager];
        NSLog(@"[][]%@",mySelfUserInfo.name);
        //判断如果没有登陆的话 就登陆
        if (!manager.xmppStream.isAuthenticated) {
            [[TRXMPPManager shareManager]initXMPPWithUserName:mySelfUserInfo.name andPassword:mySelfUserInfo.openid];
            
        }
    }];

    
}
@end
