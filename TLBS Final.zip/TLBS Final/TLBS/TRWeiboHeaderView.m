//
//  TRWeiboHeaderView.m
//  TLBS
//
//  Created by tarena on 14-9-22.
//  Copyright (c) 2014年 tarena. All rights reserved.
//

#import "TRWeiboHeaderView.h"

@implementation TRWeiboHeaderView

-(void)awakeFromNib{
    [super awakeFromNib];
    
    //初始化界面
    self.weiboView = [[TRWeiboView alloc]initWithFrame:CGRectZero];
    self.weiboView.isDetail = YES;
    [self addSubview:self.weiboView];
}

-(void)layoutSubviews{
    [super layoutSubviews];
 
    
    self.nick.text = self.weibo.user.nick;
    self.topicTime.text = self.weibo.createDate;
    self.address.text = self.weibo.location;
    [self.commentNum setTitle:[NSString stringWithFormat:@"评论 %@",self.weibo.mCount] forState:UIControlStateNormal];
    [self.transNums setTitle:[NSString stringWithFormat:@"转发 %@",self.weibo.count] forState:UIControlStateNormal];
    
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        NSData *data = [NSData dataWithContentsOfURL:[NSURL URLWithString:self.weibo.user.head]];
        
        UIImage *image = [UIImage imageWithData:data];
        dispatch_async(dispatch_get_main_queue(), ^{
            self.headImageView.image = image;
        });
    });
    
 
    //控制weiboView尺寸
    self.weiboView.frame = CGRectMake(10,60,300,[self.weibo getWeiboHeightIsDetailPage:YES]);
    //告诉weiboView显示的内容
    self.weiboView.weibo = self.weibo;
    //刷新显示
    [self.weiboView layoutSubviews];
}

@end
