//
//  TRWeiboView.h
//  TLBS
//
//  Created by tarena on 14-7-23.
//  Copyright (c) 2014年 tarena. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Weibo.h"
@interface TRWeiboView : UIView
@property (nonatomic, strong)Weibo *weibo;
@property (nonatomic, strong)UITextView *textView;
@property (nonatomic, strong)UIImageView *imageView;
@property (nonatomic)BOOL isDetail;
@property (nonatomic, strong)TRWeiboView *relWeiboView;
@end
