//
//  WeiboJsonPaser.h
//  Day10WeiboDemo
//
//  Created by apple on 13-11-25.
//  Copyright (c) 2013年 tarena. All rights reserved.
//
#import "Weibo.h"
#import <Foundation/Foundation.h>
#import "TRUserInfo.h"
#import "Comment.h"

@interface WeiboPaser : NSObject
 
+(TRUserInfo*)paseUserInfoByDictionary:(NSDictionary*)dic;

+(NSArray *)paseAllUserByJsonDic:(NSDictionary *)dic;
+(NSArray *)paseListsByJsonDic:(NSDictionary *)dic;
+(NSString *)paseListIDByDic:(NSDictionary *)dic;
//解析微博
+(Weibo*)paseWeiboByDictionary:(NSDictionary *)dic;
//解析评论
+(Comment*)paseCommentsByDictionary:(NSDictionary*)dic;
@end
