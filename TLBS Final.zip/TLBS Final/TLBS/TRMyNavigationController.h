//
//  TRMyNavigationController.h
//  TLBS
//
//  Created by tarena on 14-9-18.
//  Copyright (c) 2014年 tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TRMyNavigationController : UINavigationController

@end
