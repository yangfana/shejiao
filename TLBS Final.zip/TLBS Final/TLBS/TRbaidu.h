//
//  TRbaidu.h
//  TLBS
//
//  Created by tarena on 14-12-5.
//  Copyright (c) 2014年 tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TRbaidu : UIViewController
{
    UIWebView *webView;
}
@end
