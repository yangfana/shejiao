//
//  UserInfo.m
//  Day10WeiboDemo
//
//  Created by apple on 13-11-25.
//  Copyright (c) 2013年 tarena. All rights reserved.
//

#import "TRUserInfo.h"

@implementation TRUserInfo
@end
