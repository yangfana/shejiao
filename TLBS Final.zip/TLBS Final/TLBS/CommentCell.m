//
//  CommentCell.m
//  Day10WeiboDemo
//
//  Created by apple on 13-11-27.
//  Copyright (c) 2013年 tarena. All rights reserved.
//


#import "CommentCell.h"
@implementation CommentCell
- (id)initWithCoder:(NSCoder *)aDecoder
{
    self = [super initWithCoder:aDecoder];
    if (self) {
        [self initView];
    }
    return self;
}
-(void)initView {
    //昵称，时间
    self.nickNameLabel = [[UILabel alloc]initWithFrame:CGRectZero];
    [self.nickNameLabel setFont:[UIFont systemFontOfSize:16]];
    [self.contentView addSubview:self.nickNameLabel];
    self.timeLabel = [[UILabel alloc]initWithFrame:CGRectZero];
    [self.timeLabel setFont:[UIFont systemFontOfSize:14]];
    [self.timeLabel setTextColor:[UIColor grayColor]];
    [self.contentView addSubview:self.timeLabel];
    //头像
    self.headerIV = [[UIImageView alloc]initWithFrame:CGRectMake(10, 5, 50, 50)];
    [self.contentView addSubview:self.headerIV];
    
    self.contentLabel = [[UILabel alloc] initWithFrame:CGRectZero];
    self.contentLabel.font = [UIFont systemFontOfSize:13];
    self.contentLabel.numberOfLines = 0;
    
    [self.contentView addSubview:self.contentLabel];//添加到cell的contentView
    
    
}


-(void)layoutSubviews {
    [super layoutSubviews];
    
    //昵称_nickLabel
    self.nickNameLabel.frame = CGRectMake(70, 5, 200, 20);
    self.nickNameLabel.text = self.comment.user.nick;
    //时间
    self.timeLabel.text = self.comment.createdDate;
    self.timeLabel.frame = CGRectMake(230, 5,150, 20);
    NSString *text = self.comment.text;
    self.contentLabel.frame = CGRectMake(70, 30, 235, [self.comment getCommentHight]);
    
    self.contentLabel.text = text;
    
//    头像
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        NSData *data = [NSData dataWithContentsOfURL:[NSURL URLWithString:self.comment.user.head]];
        UIImage *image = [UIImage imageWithData:data];
        dispatch_async(dispatch_get_main_queue(), ^{
            self.headerIV.image = image;
        });
        
    });

    
}

@end
