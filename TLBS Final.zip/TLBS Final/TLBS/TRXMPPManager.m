//
//  TRXMPPManager.m
//  Day22XMPP
//
//  Created by tarena on 14-7-28.
//  Copyright (c) 2014年 Tarena. All rights reserved.
//
#import "TRMyWeiboApi.h"
#import "TRXMPPManager.h"
static TRXMPPManager *manager;
@implementation TRXMPPManager
+(TRXMPPManager *)shareManager{
    if (!manager) {
        manager = [[TRXMPPManager alloc]init];
    }
    return manager;
}
-(void)initXMPPWithUserName:(NSString *)userName andPassword:(NSString *)password{
    self.password = password;
    self.xmppStream = [[XMPPStream alloc]init];
    //设置delegate
    [self.xmppStream addDelegate:self delegateQueue:dispatch_get_main_queue()];
    //设置服务器地址 外网：124.207.192.18 内网：172.60.5.100
    [self.xmppStream setHostName:@"124.207.192.18"];
    //设置端口号
    [self.xmppStream setHostPort:5222];
    //设置当前用户的id
    //    1404xxxxx@tareng3gxmpp.com
    XMPPJID *myJID = [XMPPJID jidWithString:[NSString stringWithFormat:@"%@@tarena3gxmpp.com",userName]];
    [self.xmppStream setMyJID:myJID];
    //开始连接服务器
    [self.xmppStream connectWithTimeout:XMPPStreamTimeoutNone error:nil];

}

//连接到了服务器
-(void)xmppStreamDidConnect:(XMPPStream *)sender{
    NSLog(@"连接成功！！");
    
    //如果连接成功后 调用登陆方法
    [self.xmppStream authenticateWithPassword:self.password error:nil];
}
-(void)xmppStreamDidDisconnect:(XMPPStream *)sender withError:(NSError *)error{
    NSLog(@"断开连接");
}
//登陆成功！
-(void)xmppStreamDidAuthenticate:(XMPPStream *)sender{
    NSLog(@"登陆成功！");
    //通知服务器我在线了
    XMPPPresence *presence = [XMPPPresence presence];
    [self.xmppStream sendElement:presence];
    
    

}
-(XMPPMessage *)sendMessageBody:(NSString *)body andType:(NSString *)type andToUserName:(NSString *)toUserName{
    XMPPJID *toJID = [XMPPJID jidWithString:[NSString stringWithFormat:@"%@@tarena3gxmpp.com",toUserName]];
    XMPPMessage *message = [XMPPMessage messageWithType:type to:toJID];
    [message addBody:body];
    
    [self.xmppStream sendElement:message];
    
    return message;
}

//登陆失败
-(void)xmppStream:(XMPPStream *)sender didNotAuthenticate:(DDXMLElement *)error{
    NSLog(@"登陆失败！");
    //调用注册方法
    [self.xmppStream registerWithPassword:[TRMyWeiboApi shareWeiboApi].getToken.openid error:nil];
}

//注册成功
-(void)xmppStreamDidRegister:(XMPPStream *)sender{
    NSLog(@"注册成功");
    
    [self.xmppStream authenticateWithPassword:self.password error:nil];
}

-(void)xmppStream:(XMPPStream *)sender didNotRegister:(DDXMLElement *)error{
    NSLog(@"注册失败");
}
//接收到消息
-(void)xmppStream:(XMPPStream *)sender didReceiveMessage:(XMPPMessage *)message{
    
  
    [self.delegate didReceiveMessage:message];
}

@end
