//
//  DetailViewController.h
//  Day10WeiboDemo
//
//  Created by apple on 13-11-27.
//  Copyright (c) 2013年 tarena. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Weibo.h"
#import "TRWeiboCell.h"
@interface DetailViewController : UITableViewController<UIAlertViewDelegate,UITextFieldDelegate>
@property (nonatomic,strong)Weibo *weibo;

@end
