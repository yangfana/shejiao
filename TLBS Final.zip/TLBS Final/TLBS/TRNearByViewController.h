//
//  TRNearByViewController.h
//  TLBS
//
//  Created by tarena on 14-10-28.
//  Copyright (c) 2014年 tarena. All rights reserved.
//
#import <MapKit/MapKit.h>
#import <UIKit/UIKit.h>

@interface TRNearByViewController : UIViewController<MKMapViewDelegate>

@end
