//
//  TRChatViewController.m
//  TLBS
//
//  Created by tarena on 14-4-4.
//  Copyright (c) 2014年 tarena. All rights reserved.
//

#import "TRChatViewController.h"

#import "TRMessageCell.h"
#import "RecordButton.h"
#import "TRMyWeiboApi.h"
@interface TRChatViewController ()
@property (weak, nonatomic) IBOutlet UITextField *sendInfoTF;
@property (weak, nonatomic) IBOutlet RecordButton *recordBtn;
@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property (nonatomic, strong)TRUserInfo *mySelfInfo;
@property (nonatomic, strong)NSMutableArray *messages;

- (IBAction)sendAction:(id)sender;

@end

@implementation TRChatViewController

-(void)didReceiveMessage:(XMPPMessage *)message{
    [self.messages addObject:message];
    [self.tableView reloadData];
    [self.tableView scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:self.messages.count-1 inSection:0] atScrollPosition:UITableViewScrollPositionBottom animated:YES];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.title = self.sendToUserInfo.nick;
	self.messages = [NSMutableArray array];
    [TRXMPPManager shareManager].delegate = self;
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(WillChangeFrame:) name:UIKeyboardWillChangeFrameNotification object:nil];
    
    
    [[TRMyWeiboApi shareWeiboApi]requestUserInfo:^(id obj) {
        self.mySelfInfo = obj;
    }];
    
    self.recordBtn.delegate = self;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


-(void)sendMessageString:(NSString *)messageString andType:(NSString *)type{
   
//    text  image  audio
    XMPPMessage *message = [[TRXMPPManager shareManager]sendMessageBody:messageString andType:type andToUserName:self.sendToUserInfo.name];
    
    [message addBody:messageString];
    [self.messages addObject:message];
    [self.tableView reloadData];
    
    //保证tableview永远现实当前发送的数据
    [self.tableView scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:self.messages.count-1 inSection:0] atScrollPosition:UITableViewScrollPositionBottom animated:YES];
}
- (IBAction)sendAction:(id)sender {
    

    [self sendMessageString:self.sendInfoTF.text andType:@"message"];
}



- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
  
    return self.messages.count;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    XMPPMessage *message = self.messages[indexPath.row];
    if ([message.type isEqualToString:@"image"]||[message.type isEqualToString:@"audio"]) {
        return 50;
    }
    //下面是算cell高度的代码
    NSDictionary *attribute = @{NSFontAttributeName: [UIFont systemFontOfSize:13]};
    CGSize size = [message.body boundingRectWithSize:CGSizeMake(200, 0) options: NSStringDrawingTruncatesLastVisibleLine | NSStringDrawingUsesLineFragmentOrigin | NSStringDrawingUsesFontLeading attributes:attribute context:nil].size;
    
    
    return  size.height+40;

}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    TRMessageCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier forIndexPath:indexPath];
    XMPPMessage * message = self.messages[indexPath.row];
    cell.message = message;
    cell.delegate = self;
    cell.userInfo = self.sendToUserInfo;
    cell.mySelfInfo = self.mySelfInfo;
    return cell;
}




#pragma mark - keyboard reference
-(void)WillChangeFrame:(NSNotification *)notif{
    
    NSDictionary *info = [notif userInfo];
    NSValue *value = [info objectForKey:UIKeyboardFrameEndUserInfoKey];
    CGSize keyboardSize = [value CGRectValue].size;
    NSLog(@"%f",value.CGRectValue.origin.y);
    if (value.CGRectValue.origin.y>400) {
        [UIView animateWithDuration:.2 animations:^{
            self.tabBarView.center = CGPointMake(self.tabBarView.center.x,self.view.bounds.size.height  - self.tabBarView.bounds.size.height / 2);
            self.tableView.frame = CGRectMake(0, 0, 320, self.view.bounds.size.height  - self.tabBarView.bounds.size.height);
        }];
        
        
    }else{
        
        [UIView animateWithDuration:.2 animations:^{
            self.tabBarView.center = CGPointMake(self.tabBarView.center.x,self.view.bounds.size.height -  keyboardSize.height - self.tabBarView.bounds.size.height / 2);
            self.tableView.frame = CGRectMake(0, 0, 320, self.view.bounds.size.height  - self.tabBarView.bounds.size.height-keyboardSize.height);
            
        }];
        
        
    }
}

- (IBAction)backAction:(id)sender {
    [self.navigationController popViewControllerAnimated:YES];
}

#pragma mark 发送图片
- (IBAction)clicked:(id)sender {
    
    UIImagePickerController *ipc = [[UIImagePickerController alloc]init];
    [ipc setSourceType:UIImagePickerControllerSourceTypePhotoLibrary];
    
    ipc.delegate = self;
    [self presentViewController:ipc animated:YES completion:nil];
}

- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info{
    
    UIImage *image = [info objectForKey:@"UIImagePickerControllerOriginalImage"];
    NSURL *imageUrl = [info objectForKey:@"UIImagePickerControllerReferenceURL"];
    NSData *imageData = nil;
    if ([[imageUrl absoluteString] hasSuffix:@"PNG"]) {
        imageData = UIImagePNGRepresentation(image);
    }else{//JPG 后面参数是压缩质量0-1 1代表质量最高
        imageData = UIImageJPEGRepresentation(image, .5);
    }
    NSString *base64String = [imageData base64EncodedStringWithOptions:0];
    
    
    
    [self dismissViewControllerAnimated:YES completion:^{
        [self sendMessageString:base64String andType:@"image"];
    }];
}


- (IBAction)recordButtonAction:(UIButton *)sender {
    
    if (self.recordBtn.hidden) {
        
        [self.sendInfoTF resignFirstResponder];
        [sender setImage:[UIImage imageNamed:@"message.png"] forState:UIControlStateNormal];
        self.recordBtn.hidden = NO;
    }else{
        [self.sendInfoTF becomeFirstResponder];
        self.recordBtn.hidden = YES;
        [sender setImage:[UIImage imageNamed:@"mic.png"] forState:UIControlStateNormal];
    }
    
}

@end
