//
//  TRNearByViewController.m
//  TLBS
//
//  Created by tarena on 14-10-28.
//  Copyright (c) 2014年 tarena. All rights reserved.
//

#import "TRNearByViewController.h"
#import "Weibo.h"
#import "TRAnnotation.h"
#import "TRMyWeiboApi.h"
#import "TRMapUtils.h"
#import "TRWeiboCell.h"
@interface TRNearByViewController ()
@property (weak, nonatomic) IBOutlet MKMapView *mapView;
@property (nonatomic, strong)TRWeiboCell *weiboInfoCell;
@property (nonatomic, strong)NSMutableArray *weibos;
@end

@implementation TRNearByViewController



- (void)viewDidLoad
{
    [super viewDidLoad];
    
  
    CLLocationCoordinate2D coord;
    coord.longitude = 113.86;
    coord.latitude = 22.57;
    //显示一个默认的地址
    [self.mapView setRegion:MKCoordinateRegionMake(coord, MKCoordinateSpanMake(0.01, 0.01))];
    
    [self loadNearByWeibos];
}
-(void)loadNearByWeibos{
    //因为真机获取不到经纬度 创建一个默认的位置
    CLLocationCoordinate2D l;
    l.latitude =39.904965;
    l.longitude =116.406636;
    NSString *location = [NSString stringWithFormat:@"%f,%f",l.longitude,l.latitude];
    //给百度发请求获取weiboID
    [TRMapUtils serchPoiByLocation:location complation:^(id obj) {
        NSArray *weiboIDs = obj;
        if (weiboIDs.count!=0) {
            
            //向腾讯发请求通过weiboID获得Weibo对象
            [[TRMyWeiboApi shareWeiboApi]requestWeibosByweiboIDs:weiboIDs complation:^(id obj) {
                self.weibos = obj;
                dispatch_async(dispatch_get_main_queue(), ^{
                    [self loadAnnotations];
                });
            }];
        }
    }];
    
}

-(void)loadAnnotations{
    for (Weibo *weibo in self.weibos)
    {
        TRAnnotation *ann = [[TRAnnotation alloc]init];
        ann.weibo = weibo;
        CLLocationCoordinate2D coord;
        coord.longitude = weibo.longitude.floatValue;
        coord.latitude = weibo.latitude.floatValue;
        NSLog(@"longitude=%flatitude=%f",coord.longitude,coord.latitude);
        ann.title = weibo.user.nick;
        [ann setCoordinate:coord];
        
        
        [self.mapView addAnnotation:ann];
        
        
        
    }
    
    

}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (void)mapView:(MKMapView *)mapView didSelectAnnotationView:(MKAnnotationView *)view{
    TRAnnotation *ann = view.annotation;
    
    NSLog(@"%@",ann.title);
    if (!self.weiboInfoCell) {
      self.weiboInfoCell = [[[NSBundle mainBundle]loadNibNamed:@"TRWeiboCell" owner:self options:nil] lastObject];
            [self.view addSubview:self.weiboInfoCell];
    }
   
    self.weiboInfoCell.contentView.backgroundColor = [UIColor whiteColor];
    self.weiboInfoCell.weibo = ann.weibo;
    [self.weiboInfoCell layoutSubviews];
    
    float cellHeight = [ann.weibo getWeiboHeightIsDetailPage:NO]+120;
    self.weiboInfoCell.frame = CGRectMake(0, self.view.bounds.size.height-cellHeight, 320, cellHeight);

}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
