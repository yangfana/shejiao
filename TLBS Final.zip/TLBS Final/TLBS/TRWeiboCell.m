//
//  TRWeiboCell.m
//  TLBS
//
//  Created by tarena on 14-9-22.
//  Copyright (c) 2014年 tarena. All rights reserved.
//

#import "TRWeiboCell.h"

@implementation TRWeiboCell
-(void)awakeFromNib{
    
    [super awakeFromNib];
    
    //初始化界面
    self.weiboView = [[TRWeiboView alloc]initWithFrame:CGRectZero];
    
    [self addSubview:self.weiboView];

}
- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];
    
    // Configure the view for the selected state
}

-(void)layoutSubviews{
    [super layoutSubviews];
    
    
    self.nick.text = self.weibo.user.nick;
    self.topicTime.text = self.weibo.createDate;
    self.address.text = self.weibo.location;
    [self.commentNum setTitle:self.weibo.mCount forState:UIControlStateNormal];
    [self.transNums setTitle:self.weibo.count forState:UIControlStateNormal];
    
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        NSData *data = [NSData dataWithContentsOfURL:[NSURL URLWithString:self.weibo.user.head]];
        
        UIImage *image = [UIImage imageWithData:data];
        dispatch_async(dispatch_get_main_queue(), ^{
            self.headImageView.image = image;
        });
    });
    
    
    //控制weiboView尺寸
    self.weiboView.frame = CGRectMake(60, 30, 260, [self.weibo getWeiboHeightIsDetailPage:NO]);
    //告诉weiboView显示的内容
    self.weiboView.weibo = self.weibo;
    //刷新显示
    [self.weiboView layoutSubviews];
 
}

@end
