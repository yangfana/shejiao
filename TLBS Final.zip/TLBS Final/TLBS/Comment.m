//
//  Comment.m
//  Day10WeiboDemo
//
//  Created by apple on 13-11-27.
//  Copyright (c) 2013年 tarena. All rights reserved.
//

#import "Comment.h"


@implementation Comment
-(float)getCommentHight{
    
    CGRect frame = [self.text boundingRectWithSize:CGSizeMake(290, 999) options:NSStringDrawingUsesLineFragmentOrigin  attributes:@{NSFontAttributeName : [UIFont systemFontOfSize:14]} context:nil];
    
    return frame.size.height;
}
@end
